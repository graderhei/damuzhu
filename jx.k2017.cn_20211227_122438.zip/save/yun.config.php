<?php
$YUN_CONFIG=array (
  'name_filter' => '激情|写真|成人|福利',
  'flag_filter' => '',
  'jmp_off' => '1',
  'url_filter' => '',
  'type_filter' => '福利|伦理',
);
