<?php
 $yzm =  array (
  'time' => '1',
  'ads' => 
  array (
    'set' => 
    array (
      'group' => '1',
      'state' => '1',
      'pic' => 
      array (
        'time' => '30',
        'img' => '',
        'link' => '',
      ),
      'vod' => 
      array (
        'url' => '',
        'link' => '',
      ),
    ),
    'pause' => 
    array (
      'pic' => 'http://alltv.vip/app.png',
      'link' => '../../../plus/app/app.apk',
    ),
  ),
  'count' => '10-100',
  'color' => '#00a1d6',
  'font_color' => '#fff',
  'background_color' => '#8B008B 0%,#00000A 80%',
  'background_url' => 'img/20200519223109.gif',
  'pic' => 'img/20200519222902.jpg',
  'logo' => '',
  'trytime' => '999999999999',
  'waittime' => '2',
  'sendtime' => '5',
  'dmrule' => '../../dmku/dm_rule.html',
  'pbgjz' => '草,操,妈,逼,滚,网址,AV,黄片,网站,支付,企,关注,wx,微信,qq,QQ',
  'style' => '/* logo */
.yzmplayer-logo{
right: 5% !important;
top: 5% !important;
}
',
);
?>